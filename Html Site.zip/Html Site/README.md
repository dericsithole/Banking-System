# Mega Bank Sandbox

A local-only Mega Bank website prototype. Customer registration, sign-in, and account, card, and transfer requests are stored in a local JSON file. It does not create sample balances or process transactions.

## Run locally

Requires Node.js 20 or newer. From this folder, run:

```powershell
npm start
```

Open http://127.0.0.1:3000. Register with your own name, email, and password. Each page requires an authenticated customer session. Requests stay pending and are not processed.

To check JavaScript syntax:

```powershell
npm run check
```

Customer records and submitted requests are saved under `data/bank.json`. The `data` folder is excluded from Git. Deleting that file resets the local sandbox.

## Security and scope

This prototype is not a real bank and does not connect to payment networks, cards, bank accounts, identity verification, or financial institutions. Do not enter real financial credentials or sensitive customer information. The local JSON store is not encrypted at rest and is not suitable for deployment or real customer data. A production financial service requires a security review, compliant infrastructure, licensed providers, identity verification, fraud controls, audit processes, and regulatory approval.
